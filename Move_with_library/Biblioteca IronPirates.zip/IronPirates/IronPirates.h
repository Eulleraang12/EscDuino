/* 
 *  biblioteca para ponte h 
 *  IronPirates.h
 *  autor: Eng Euller Barros
 *  biblioteca para facilitar os comandos da ponte h para o primeiro robo da IronPirates
 */

#ifndef IronPirates_n
#define IronPirates_n
#include <Arduino.h>

// direcao do motor
#define backward  1
#define forward 0

class IronPiratesMotors{

  public:
    IronPiratesMotors(int ENA, int IN1, int IN2, int ENB, int IN3, int IN4);

    void leftMotor(int vel, boolean direcao); //motor esquerdo 
    void rightMotor(int vel, boolean direcao); //motor direito 

    void stopped(); // motores parados 

    void twoMotors(int vel, boolean direcao);// motores andando 

    void leftBrake(int vel); //motor esquerdo freiando 
    void rightBrake(int vel); //motor direito freiando 
  
  private:
    int _ENA;
    int _IN1;
    int _IN2; 
    int _ENB;
    int _IN3; 
    int _IN4;
    
};

#endif
