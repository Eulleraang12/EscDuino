/* 
 *  biblioteca para ponte h 
 *  IronPirates.h
 *  autor: Eng Euller Barros
 *  biblioteca para facilitar os comandos da ponte h para o primeiro robo da IronPirates
 */
#include "IronPirates.h"
#include <Arduino.h>

IronPiratesMotors::IronPiratesMotors(int ENA, int IN1, int IN2, int ENB, int IN3, int IN4){

  pinMode(ENA, OUTPUT);
  pinMode(IN1, OUTPUT);
  pinMode(IN2, OUTPUT);
  pinMode(ENB, OUTPUT);
  pinMode(IN3, OUTPUT);
  pinMode(IN4, OUTPUT);

  _ENA = ENA;
  _IN1 = IN1;
  _IN2 = IN2;
  _ENB = ENB;
  _IN3 = IN3;
  _IN4 = IN4;
}
//===============================================================================
void IronPiratesMotors::leftMotor(int vel, boolean direcao){ //motor esquerdo

       analogWrite(_ENA, vel);
       digitalWrite(_IN1, direcao);
       digitalWrite(_IN2, !direcao); 
  }

void IronPiratesMotors::rightMotor(int vel, boolean direcao){ //motor direito

       analogWrite(_ENB, vel);
       digitalWrite(_IN3, direcao);
       digitalWrite(_IN4, !direcao); 
  }
//=================================================================================

void IronPiratesMotors::stopped(){ // motores parados 
  analogWrite(_ENA, 0);
  analogWrite(_ENB, 0);
  }
//=================================================================================
void IronPiratesMotors::leftBrake(int vel){//motor esquerdo freiando 
      
       analogWrite(_ENA, vel);
       digitalWrite(_IN1, HIGH);
       digitalWrite(_IN2, HIGH); 
    }

void IronPiratesMotors::rightBrake(int vel){//motor direito freiando 
      
       analogWrite(_ENB, vel);
       digitalWrite(_IN3, HIGH);
       digitalWrite(_IN4, HIGH); 
    }
//=================================================================================

void IronPiratesMotors::twoMotors(int vel, boolean direcao){// motores andando

      leftMotor(vel, direcao);
      rightMotor(vel, direcao);
    }













